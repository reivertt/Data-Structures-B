#include <stdio.h>
#include <string.h>

typedef struct {
    char nrp[11];
    int class[7];
}input;

typedef struct {
    char nrp[101][11];
    int count;
}course;

int main(){
    FILE *fp = fopen("2_12i.txt", "r");
    input input[101];
    course course[7];
    for(int y = 0; y < 6; y++) course[y].count = 0;
    for(int i = 0; i > -1; i++){
        fscanf(fp, "%s", input[i].nrp);
        if (!strcmp(input[i].nrp, "0")) break;
        for(int j = 0; j < 6; j++){
            fscanf(fp, "%d", &input[i].class[j]);
            if(input[i].class[j]) strcpy(course[j].nrp[course[j].count++], input[i].nrp);
        }
    }
    printf("DATA\n");
    for(int k = 0; k < 6; k++){
        printf("------------------------------------------------------\n");
        printf("Kelas %d, %d Peserta\n", k+1, course[k].count);
        for(int l = 0; l < course[k].count; l++){
            printf("- %s\n", course[k].nrp[l]);
        }
        printf("\n------------------------------------------------------\n");
    }
}